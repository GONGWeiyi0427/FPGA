#include "xil_io.h"
#include "my_led.h"
#include "xgpio.h"
#include "xparameters.h"

int main()
{
	XGpio sw;
	u32 data;


	XGpio_Initialize(&sw,XPAR_GPIO_0_DEVICE_ID);

	XGpio_SetDataDirection(&sw,1,0xF);

	while(1)
	{
		data=XGpio_DiscreteRead(&sw,1);

		MY_LED_mWriteReg(XPAR_MY_LED_0_S00_AXI_BASEADDR,MY_LED_S00_AXI_SLV_REG0_OFFSET,data);
		MY_LED_mWriteReg(XPAR_MY_LED_0_S00_AXI_BASEADDR,MY_LED_S00_AXI_SLV_REG1_OFFSET,data>>2);


	}

	return 0;
}
