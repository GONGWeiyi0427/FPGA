#include "xgpio.h"
#include "xparameters.h"




int main()
{
	XGpio led_sw,bouton;
	int led=0x0000;
	int cpt;
	int comp=0x0000;
	int sw_state;
	int bouton_state;
	int mask0=0b0001;
	int mask1=0b0010;
	int maskbc=0b010;
	int maskbl=0b100;
	int maskbr=0b001;

	int bpc_dernier=0b000;

	XGpio_Initialize(&led_sw,XPAR_LED_SWITCH_DEVICE_ID);
	XGpio_Initialize(&bouton,XPAR_BOUTONS_DEVICE_ID);

	XGpio_SetDataDirection(&led_sw,1,0xF);
	XGpio_SetDataDirection(&led_sw,2,0);
	XGpio_SetDataDirection(&bouton,1,0xF);



	while(1){
		sw_state = XGpio_DiscreteRead(&led_sw,1);
		bouton_state = XGpio_DiscreteRead(&bouton,1);
		int q0=sw_state & mask0;
		int q1=sw_state & mask1;
		int qbc=bouton_state & maskbc;
		int qbl=bouton_state & maskbl;
		int qbr=bouton_state & maskbr;

		if(q0==0b0001)//If switch0=1
		{
			led=led|(0xFF00);
			XGpio_DiscreteWrite(&led_sw,2, led );
			for(cpt=0;cpt<450000;cpt++){}
			led=led&(0x00FF);
			XGpio_DiscreteWrite(&led_sw,2, led);
			for(cpt=0;cpt<450000;cpt++){}
		}

/*
		else if(q0!=0b0001)//If switch0=0
		{
			led=led&(0x00FF);
			XGpio_DiscreteWrite(&led_sw,2,led);
		}
*/


		if(q1==0b0010)//If switch1=1
		{
			if(qbc==0b010)
			{
				if(bpc_dernier==0b000)
				{
					comp++;
					if(comp==0x0010){comp=0x0000;}
				}

			}
			led=led&(0xFFF0);
			led=led|comp;
			XGpio_DiscreteWrite(&led_sw,2,led);
			bpc_dernier=qbc;

			if(qbl==0b100)
			{
				led=led|(0x00F0);
				XGpio_DiscreteWrite(&led_sw,2,led);
			}
			if(qbr==0b001)
			{
				led=led&(0xFF0F);
				XGpio_DiscreteWrite(&led_sw,2,led);
			}

		}
		else if(q1==0x0000)
		{
			led=led&(0xFF00);
			XGpio_DiscreteWrite(&led_sw,2,led);
		}


	}




}
